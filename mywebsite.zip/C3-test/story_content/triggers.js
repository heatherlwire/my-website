function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xaijKRhgSH":
        Script1();
        break;
      case "5kgtJ8cQqwm":
        Script2();
        break;
      case "5z5Pv8DQgv8":
        Script3();
        break;
      case "6OpFXZoFvMl":
        Script4();
        break;
      case "5lndp3mIOx5":
        Script5();
        break;
      case "6SBW9V2iElh":
        Script6();
        break;
      case "5y5WSqXDwiV":
        Script7();
        break;
      case "6KZuzczptsE":
        Script8();
        break;
      case "6DljBOUIrYJ":
        Script9();
        break;
      case "6e6YwUMRCwe":
        Script10();
        break;
      case "5gkvIZQpfcr":
        Script11();
        break;
      case "5cVOKK8Ogde":
        Script12();
        break;
      case "6pN0LQwObB6":
        Script13();
        break;
      case "5kIRjmBq9vQ":
        Script14();
        break;
      case "5Unx2kCP5bO":
        Script15();
        break;
      case "6aZxTxWcyul":
        Script16();
        break;
      case "6jijzhv6vPV":
        Script17();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
