function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6D5iEh5QS5x":
        Script1();
        break;
      case "5fID0L1m7wY":
        Script2();
        break;
      case "6gvkLVoFb2q":
        Script3();
        break;
      case "6VuvaeVdgtq":
        Script4();
        break;
      case "662A9EHVEo2":
        Script5();
        break;
      case "6UxhpdYARyb":
        Script6();
        break;
      case "5yQ2YnhQgh6":
        Script7();
        break;
      case "6mvd2O7z0Ly":
        Script8();
        break;
      case "6VemGDOhk9S":
        Script9();
        break;
      case "5yWo2Eb3oSW":
        Script10();
        break;
      case "69xKNEjYXJB":
        Script11();
        break;
      case "5zyKZQSsbGM":
        Script12();
        break;
      case "6Z2BDlGDCQK":
        Script13();
        break;
      case "6SjNKlfVVTw":
        Script14();
        break;
      case "6aYOyjbIjNV":
        Script15();
        break;
      case "5W7JsdpPWhL":
        Script16();
        break;
      case "6WJxzgrqi3f":
        Script17();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
