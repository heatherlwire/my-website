function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6QQ5YdLfCBK":
        Script1();
        break;
      case "6kum6ghQ5ZD":
        Script2();
        break;
      case "6YCsAqyjImI":
        Script3();
        break;
      case "5YYMxE8KioY":
        Script4();
        break;
      case "6P8ydmBGO32":
        Script5();
        break;
      case "6aIkHDYs704":
        Script6();
        break;
      case "5geeLWpJllj":
        Script7();
        break;
      case "5ggEiKR0AFI":
        Script8();
        break;
      case "6Vo2K69JK8z":
        Script9();
        break;
      case "5gs1rSNkmZc":
        Script10();
        break;
      case "5kpzYNAp2Q6":
        Script11();
        break;
      case "5bX6K5Gr2Y2":
        Script12();
        break;
      case "6a1TbLLbqp1":
        Script13();
        break;
      case "6puKJMcod12":
        Script14();
        break;
      case "6BJyDa5T2Du":
        Script15();
        break;
      case "6Xl9C8VRSJS":
        Script16();
        break;
      case "6rVLT66rxV3":
        Script17();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
