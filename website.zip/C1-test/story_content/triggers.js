function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ETuU77FlOS":
        Script1();
        break;
      case "65nxhcgJs5U":
        Script2();
        break;
      case "6eZF6yz61yI":
        Script3();
        break;
      case "5sGzFnzf9ml":
        Script4();
        break;
      case "6nFzPQcWUyz":
        Script5();
        break;
      case "5bmdOyTPTtw":
        Script6();
        break;
      case "6roGXrJEnSL":
        Script7();
        break;
      case "6PDEmZgNogT":
        Script8();
        break;
      case "5m42g3aOLxv":
        Script9();
        break;
      case "5VSrmctYFnz":
        Script10();
        break;
      case "6DBPeLKi7zi":
        Script11();
        break;
      case "6J3ElJ4TwMW":
        Script12();
        break;
      case "6k9f3nWcfGS":
        Script13();
        break;
      case "5Vlz1a8kRHU":
        Script14();
        break;
      case "6jo8mZ033hr":
        Script15();
        break;
      case "5zrpd7d16i2":
        Script16();
        break;
      case "5xHAiv7HCHt":
        Script17();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
